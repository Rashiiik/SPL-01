/*
 * Problem: Smallest Period of a String
 *
 * A string has period k if it can be formed by repeating a substring of
 * length k one or more times. Find the smallest such period k.
 *
 * Input:
 *   - First line: N (number of test cases), followed by blank line
 *   - Each test case: one string of up to 80 non-blank characters
 *   - Consecutive test cases separated by blank lines
 *
 * Output:
 *   - Smallest period for each string
 *   - Consecutive outputs separated by blank lines
 *
 * Approach: KMP Failure Function
 *   fail[i] = length of longest proper prefix of s[0..i] that is also a suffix
 *
 *   Key insight:
 *     period = len - fail[len - 1]
 *     If len % period == 0 → period is exact, answer = period
 *     If len % period != 0 → string doesn't perfectly repeat,
 *                            smallest period = len (the whole string itself)
 *
 *   Example: "HoHoHo", len=6
 *     fail = [0, 0, 1, 2, 3, 4]
 *     period = 6 - 4 = 2
 *     6 % 2 == 0 → answer = 2  ✓
 */

#include <stdio.h>
#include <string.h>

#define MAXLEN 85

int fail[MAXLEN];

void computeFailure(char *s, int len) {
    fail[0] = 0;
    int k = 0;
    for (int i = 1; i < len; i++) {
        while (k > 0 && s[k] != s[i])
            k = fail[k - 1];
        if (s[k] == s[i]) k++;
        fail[i] = k;
    }
}

int main() {
    int N;
    scanf("%d", &N);

    char s[MAXLEN];
    for (int t = 0; t < N; t++) {
        if (t > 0) printf("\n");

        scanf("%s", s);
        int len = strlen(s);

        computeFailure(s, len);

        int period = len - fail[len - 1];
        if (len % period != 0)
            period = len; /* whole string is the only period */

        printf("%d\n", period);
    }

    return 0;
}