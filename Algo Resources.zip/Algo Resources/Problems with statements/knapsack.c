#include <stdio.h>

int max(int a, int b) {
    return (a > b) ? a : b;
}

int knapsack01(int w[], int v[], int n, int W) {
    int P[n + 1][W + 1];

    int i;
    int wgt;

    
    for (i = 0; i <= n; i++)
        P[i][0] = 0;

    for (wgt = 0; wgt <= W; wgt++)
        P[0][wgt] = 0;

    for (i = 1; i <= n; i++) {
        for (wgt = 0; wgt <= W; wgt++) {
            if (w[i - 1] > wgt) {
                P[i][wgt] = P[i - 1][wgt];
            } else {
                P[i][wgt] = max(
                    v[i - 1] + P[i - 1][wgt - w[i - 1]],
                    P[i - 1][wgt]
                );
            }
        }
    }

    return P[n][W];
}

int main() {
    int t;
    scanf("%d", &t);

    int arr[t];

    int i, j;

    for (i = 0; i < t; i++)
    {
        int count = 0;
        int n;
        scanf("%d", &n);

        int weights[n];
        int values[n];

        for (j = 0; j < n; j++)
        {
            scanf("%d %d", &values[j], &weights[j]);
        }

        int x;

        scanf("%d", &x);

        int people[x];

        for (j = 0; j < x; j++)
        {
            scanf("%d", &people[j]);
        }

        for (j = 0; j < x; j++)
        {
           count += knapsack01(weights, values, n, people[j]);
        }

        arr[i] = count;
        
    }

    for (i = 0; i < t; i++)
    {
        printf("%d\n", arr[i]);
    }

    return 0;
}
