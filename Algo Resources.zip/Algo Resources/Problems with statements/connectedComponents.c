/*
 * Problem: Connected Components (Maximal Connected Subgraphs)
 *
 * Given an undirected graph, determine the number of maximal connected
 * subgraphs (i.e., connected components). A connected subgraph is maximal
 * if no additional node or edge from the original graph can be added while
 * keeping it connected.
 *
 * Input:
 *   - First line: number of test cases T
 *   - Each test case (separated by blank lines):
 *       * First line: a single uppercase letter representing the largest node
 *         name in the graph (nodes are labeled A through that letter)
 *       * Successive lines: pairs of uppercase letters denoting edges (e.g. "AB")
 *       * Test case ends at a blank line or EOF
 *
 * Output:
 *   - For each test case, print the number of maximal connected subgraphs.
 *   - Consecutive outputs are separated by a blank line.
 *
 * Approach: Union-Find (Disjoint Set Union) with path compression.
 *   Each node starts as its own component. For every edge, merge the two
 *   endpoints' sets. Finally, count nodes that are their own root —
 *   each represents one connected component.
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

int parent[26];

int find(int x) {
    if (parent[x] != x)
        parent[x] = find(parent[x]);
    return parent[x];
}

void unite(int x, int y) {
    int px = find(x), py = find(y);
    if (px != py)
        parent[px] = py;
}

int main() {
    int T;
    scanf("%d", &T);

    char line[10];
    // consume rest of first line
    fgets(line, sizeof(line), stdin);

    for (int t = 0; t < T; t++) {
        if (t > 0) printf("\n");

        // Skip blank lines between test cases
        char maxNode[10];
        do {
            if (!fgets(maxNode, sizeof(maxNode), stdin)) break;
        } while (maxNode[0] == '\n' || maxNode[0] == '\r');

        int maxIdx = toupper(maxNode[0]) - 'A';

        // Initialize Union-Find for nodes A..maxNode
        for (int i = 0; i <= maxIdx; i++)
            parent[i] = i;

        // Read edges until blank line or EOF
        while (fgets(line, sizeof(line), stdin)) {
            if (line[0] == '\n' || line[0] == '\r') break;
            if (isalpha(line[0]) && isalpha(line[1])) {
                int u = toupper(line[0]) - 'A';
                int v = toupper(line[1]) - 'A';
                unite(u, v);
            }
        }

        // Count distinct roots
        int count = 0;
        for (int i = 0; i <= maxIdx; i++)
            if (find(i) == i) count++;

        printf("%d\n", count);
    }

    return 0;
}