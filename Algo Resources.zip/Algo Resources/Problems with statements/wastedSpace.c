/*
 * Problem: Useless Tile Packers - Wasted Space Percentage
 *
 * A tile (simple polygon) is packed in a custom container whose floor is
 * the convex hull of the tile. Wasted space = area inside the convex hull
 * but outside the tile polygon.
 *
 * Output: (convexHullArea - polygonArea) / convexHullArea * 100 %
 *
 * Input:
 *   - Multiple test cases until N = 0
 *   - Each: N corner points (x, y) in order (CW or CCW)
 *
 * Output:
 *   - "Tile #k"
 *   - "Wasted Space = X.XX %"
 *   - Blank line after each tile
 *
 * Approach:
 *   1. Compute polygon area using the Shoelace formula
 *   2. Compute convex hull using Graham Scan
 *   3. Compute convex hull area using Shoelace formula
 *   4. Wasted % = (hullArea - polyArea) / hullArea * 100
 *
 * Note: Shoelace gives signed area; we take absolute value.
 *       Polygon points may be CW or CCW — abs() handles both.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAXN 105

typedef struct { double x, y; } Point;

Point pts[MAXN];   /* original polygon  */
Point hull[MAXN];  /* convex hull       */
int   hullSz;

/* ---- Shoelace formula: signed area * 2 ---- */
double twice_area(Point *p, int n) {
    double area = 0;
    for (int i = 0; i < n; i++) {
        int j = (i + 1) % n;
        area += p[i].x * p[j].y;
        area -= p[j].x * p[i].y;
    }
    return area; /* positive = CCW, negative = CW */
}

/* ---- Cross product of vectors (O->A) and (O->B) ---- */
double cross(Point O, Point A, Point B) {
    return (A.x - O.x) * (B.y - O.y) - (A.y - O.y) * (B.x - O.x);
}

/* ---- Comparator for Graham Scan (sort by angle from pivot) ---- */
Point pivot;
int cmp(const void *a, const void *b) {
    Point *p = (Point *)a, *q = (Point *)b;
    double c = cross(pivot, *p, *q);
    if (c != 0) return (c > 0) ? -1 : 1;
    /* collinear: sort by distance */
    double dp = (p->x-pivot.x)*(p->x-pivot.x) + (p->y-pivot.y)*(p->y-pivot.y);
    double dq = (q->x-pivot.x)*(q->x-pivot.x) + (q->y-pivot.y)*(q->y-pivot.y);
    return (dp < dq) ? -1 : 1;
}

/* ---- Graham Scan convex hull ---- */
void convexHull(Point *p, int n) {
    /* Find bottom-most (then left-most) point as pivot */
    int minIdx = 0;
    for (int i = 1; i < n; i++)
        if (p[i].y < p[minIdx].y || (p[i].y == p[minIdx].y && p[i].x < p[minIdx].x))
            minIdx = i;

    /* Swap pivot to front */
    Point tmp = p[0]; p[0] = p[minIdx]; p[minIdx] = tmp;
    pivot = p[0];

    /* Sort remaining points by polar angle */
    qsort(p + 1, n - 1, sizeof(Point), cmp);

    /* Graham scan */
    hull[0] = p[0];
    hull[1] = p[1];
    hullSz  = 2;

    for (int i = 2; i < n; i++) {
        while (hullSz > 1 && cross(hull[hullSz-2], hull[hullSz-1], p[i]) <= 0)
            hullSz--;
        hull[hullSz++] = p[i];
    }
}

int main() {
    int n, caseNum = 1;

    while (scanf("%d", &n) == 1 && n != 0) {
        Point p[MAXN];
        for (int i = 0; i < n; i++)
            scanf("%lf %lf", &p[i].x, &p[i].y);

        /* Polygon area (Shoelace) */
        double polyArea = fabs(twice_area(p, n)) / 2.0;

        /* Convex hull + its area */
        convexHull(p, n);
        double hullArea = fabs(twice_area(hull, hullSz)) / 2.0;

        double wasted = 0.0;
        if (hullArea > 1e-9)
            wasted = (hullArea - polyArea) / hullArea * 100.0;

        printf("Tile #%d\n", caseNum++);
        printf("Wasted Space = %.2f %%\n\n", wasted);
    }

    return 0;
}