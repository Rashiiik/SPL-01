/*
 * Problem: DNA Longest Common Subsequence
 *
 * Given two DNA strands (strings over {a,t,c,g}), find ALL longest common
 * subsequences and print them in lexicographical order.
 *
 * Input:
 *   - Multiple test cases separated by blank lines
 *   - Each test case: two strings (up to 300 chars each)
 *
 * Output:
 *   - All LCS strings in lexicographical order, one per line
 *   - If none: "No common sequence."
 *   - Blank line between consecutive outputs
 *
 * Approach:
 *   1. Standard LCS DP to fill dp[i][j] = LCS length of s1[0..i-1], s2[0..j-1]
 *   2. Backtrack recursively from dp[n][m] to collect ALL distinct LCS strings
 *   3. Store results in a set (sorted, deduplicated) and print in order
 *
 * Complexity: O(n*m) for DP. Backtracking can be exponential in worst case
 *   but strings are short (≤300) and DNA alphabet is small (4 chars).
 *   We deduplicate using a sorted string array.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXLEN 305
#define MAXRESULTS 100000

int dp[MAXLEN][MAXLEN];
char s1[MAXLEN], s2[MAXLEN];
int n, m;

/* Storage for all distinct LCS strings */
char results[MAXRESULTS][MAXLEN];
int resCnt;

/* Check if string already stored */
int exists(char *str) {
    for (int i = 0; i < resCnt; i++)
        if (strcmp(results[i], str) == 0) return 1;
    return 0;
}

/* Recursive backtrack to collect all LCS strings */
void backtrack(int i, int j, char *current, int depth) {
    if (i == 0 || j == 0) {
        current[depth] = '\0';
        /* Reverse the string (built backwards) */
        char tmp[MAXLEN];
        int len = depth;
        for (int k = 0; k < len; k++)
            tmp[k] = current[len - 1 - k];
        tmp[len] = '\0';
        if (!exists(tmp) && resCnt < MAXRESULTS)
            strcpy(results[resCnt++], tmp);
        return;
    }

    if (s1[i-1] == s2[j-1]) {
        current[depth] = s1[i-1];
        backtrack(i-1, j-1, current, depth+1);
    } else {
        if (dp[i-1][j] >= dp[i][j-1])
            backtrack(i-1, j, current, depth);
        if (dp[i][j-1] >= dp[i-1][j])
            backtrack(i, j-1, current, depth);
    }
}

int cmp(const void *a, const void *b) {
    return strcmp((char *)a, (char *)b);
}

int main() {
    int first = 1;

    while (scanf("%s %s", s1, s2) == 2) {
        if (!first) printf("\n");
        first = 0;

        n = strlen(s1);
        m = strlen(s2);

        /* Build LCS DP table */
        for (int i = 0; i <= n; i++) dp[i][0] = 0;
        for (int j = 0; j <= m; j++) dp[0][j] = 0;

        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= m; j++) {
                if (s1[i-1] == s2[j-1])
                    dp[i][j] = dp[i-1][j-1] + 1;
                else
                    dp[i][j] = dp[i-1][j] > dp[i][j-1] ? dp[i-1][j] : dp[i][j-1];
            }

        resCnt = 0;

        if (dp[n][m] == 0) {
            printf("No common sequence.\n");
            continue;
        }

        char current[MAXLEN];
        backtrack(n, m, current, 0);

        /* Sort lexicographically */
        qsort(results, resCnt, sizeof(results[0]), cmp);

        for (int i = 0; i < resCnt; i++)
            printf("%s\n", results[i]);
    }

    return 0;
}