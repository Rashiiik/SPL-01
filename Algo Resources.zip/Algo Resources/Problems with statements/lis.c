/*
 * Problem: Exam Partial Credit - Longest Common Subsequence of Orders
 *
 * Given the correct chronological ORDER of n events and a student's ranking,
 * find the length of the longest subsequence of events that the student has
 * in the correct relative order — i.e., LIS after mapping student ranks
 * to correct positions.
 *
 * Key insight (ranking vs ordering):
 *   correct[i] = rank of event i in correct order  (input: correct chronological order)
 *   student[i] = rank of event i in student order  (input: student's ranking)
 *
 *   We need to find events ordered correctly relative to each other.
 *   Map each event to its correct position using pos[]:
 *     pos[correct[i]] = i  → correct position of event that has rank correct[i]
 *
 *   Then for each student rank r1..rn, look up pos[ri] — the correct position
 *   of the event the student placed at rank i.
 *
 *   The student respects correct order for a subsequence of events
 *   ⟺ their correct positions form an increasing subsequence.
 *   So: find LIS of the sequence (pos[r1], pos[r2], ..., pos[rn]).
 *
 * Input:
 *   - One or more test cases
 *   - First line: n (number of events, 2 ≤ n ≤ 20)
 *   - Second line: correct chronological order (permutation of 1..n)
 *   - Remaining lines: each is one student's ranking (permutation of 1..n)
 *   - EOF terminates input
 *
 * Output:
 *   - One score per student per line (LIS length)
 *
 * Approach: O(n^2) DP for LIS — fine since n ≤ 20
 *   dp[i] = length of LIS ending at position i
 *   dp[i] = 1 + max(dp[j]) for all j < i where seq[j] < seq[i]
 */

#include <stdio.h>

#define MAXN 25

int main() {
    int n;
    while (scanf("%d", &n) == 1) {
        int correct[MAXN]; /* correct[i] = rank of event i in correct order */
        int pos[MAXN + 1]; /* pos[rank] = which position in correct order */

        for (int i = 0; i < n; i++) {
            scanf("%d", &correct[i]);
            pos[correct[i]] = i; /* event with correct rank correct[i] is at position i */
        }

        int student[MAXN];
        /* Read student rankings until next test case or EOF */
        /* We read line by line; since n<=20, just try reading n ints */
        while (1) {
            /* Try to read n integers for one student */
            int ok = 1;
            for (int i = 0; i < n; i++) {
                if (scanf("%d", &student[i]) != 1) { ok = 0; break; }
            }
            if (!ok) break;

            /*
             * Build sequence: for each student rank position i (0..n-1),
             * student[i] is the event the student placed at rank i+1.
             * Map to correct position: pos[student[i]]
             */
            int seq[MAXN];
            for (int i = 0; i < n; i++)
                seq[i] = pos[student[i]];

            /* LIS via O(n^2) DP */
            int dp[MAXN];
            int best = 1;
            for (int i = 0; i < n; i++) {
                dp[i] = 1;
                for (int j = 0; j < i; j++)
                    if (seq[j] < seq[i] && dp[j] + 1 > dp[i])
                        dp[i] = dp[j] + 1;
                if (dp[i] > best) best = dp[i];
            }

            printf("%d\n", best);

            /* Peek: if next char starts a new test case (non-digit after
               whitespace), the outer while(scanf("%d",&n)) will catch it */
        }
    }

    return 0;
}