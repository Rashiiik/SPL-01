#include <stdio.h>
#include <limits.h>

#define MAX 10000

int main() {
    int coins[] = {1, 5, 10, 25, 50};
    int n = sizeof(coins) / sizeof(coins[0]);
    int x;

    int i;
    int j;

    long long int dp[MAX];

    dp[0] = 1;

    for (i = 1; i < MAX; i++)
    {
        dp[i] = 0;
    }

    for (i = 0; i < n; i++)
    {
        for (j = coins[i]; j < MAX; j++)
        {
            dp[j] += dp[j-coins[i]]; 
        }
        
    }
    
    while (scanf("%d", &x) == 1)
    {
        printf("%d\n", dp[x]);
    }
    
    
    return 0;
}