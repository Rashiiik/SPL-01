/*
 * Problem: Sound Pollution - Minimum Bottleneck Path
 *
 * Given a city map (graph) where each street has a sound intensity level,
 * find the path from crossing c1 to c2 that minimizes the MAXIMUM intensity
 * encountered along the path (i.e., the minimax path / bottleneck path).
 *
 * Input:
 *   - Multiple test cases until "0 0 0"
 *   - Each test case:
 *       * First line: C (crossings), S (streets), Q (queries)
 *       * Next S lines: c1 c2 d  → undirected edge with intensity d
 *       * Next Q lines: c1 c2    → query: min tolerable intensity from c1 to c2
 *
 * Output:
 *   - "Case #x" header for each test case
 *   - For each query: minimum max-intensity on any path, or "no path"
 *   - Blank line between consecutive test cases
 *
 * Approach: Floyd-Warshall adapted for minimax.
 *   dist[i][j] = minimum possible maximum edge weight on any path from i to j.
 *   Recurrence: dist[i][j] = min(dist[i][j], max(dist[i][k], dist[k][j]))
 *   With C <= 100, O(C^3) Floyd-Warshall is fast enough even for Q=10000 queries.
 */

#include <stdio.h>

#define MAXC 101
#define INF  99999999

int dist[MAXC][MAXC];

void floydWarshall(int C) {
    for (int k = 1; k <= C; k++)
        for (int i = 1; i <= C; i++)
            for (int j = 1; j <= C; j++) {
                int through = (dist[i][k] > dist[k][j]) ? dist[i][k] : dist[k][j];
                if (through < dist[i][j])
                    dist[i][j] = through;
            }
}

int main() {
    int C, S, Q;
    int caseNum = 1;
    int firstCase = 1;

    while (scanf("%d %d %d", &C, &S, &Q) == 3 && (C || S || Q)) {
        if (!firstCase) printf("\n");
        firstCase = 0;

        /* Initialize dist matrix */
        for (int i = 1; i <= C; i++)
            for (int j = 1; j <= C; j++)
                dist[i][j] = (i == j) ? 0 : INF;

        /* Read streets */
        for (int i = 0; i < S; i++) {
            int c1, c2, d;
            scanf("%d %d %d", &c1, &c2, &d);
            /* Keep minimum direct edge if multiple edges exist */
            if (d < dist[c1][c2]) {
                dist[c1][c2] = d;
                dist[c2][c1] = d;
            }
        }

        floydWarshall(C);

        printf("Case #%d\n", caseNum++);

        for (int i = 0; i < Q; i++) {
            int c1, c2;
            scanf("%d %d", &c1, &c2);
            if (dist[c1][c2] == INF)
                printf("no path\n");
            else
                printf("%d\n", dist[c1][c2]);
        }
    }

    return 0;
}