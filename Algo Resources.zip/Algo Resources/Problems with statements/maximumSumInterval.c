#include <stdio.h>

#define MAXN 10000

int A[MAXN + 1];     
int Sum[MAXN + 1];   
int Prev[MAXN + 1];  
int n;
int maxSum, maxEnd;

int maximumSum() {
    
    Sum[0] = 0;
    maxSum = A[1];
    maxEnd = 1;
    int i;

    for (i = 1; i <= n; i++) {
        
        
        Sum[i] = Sum[i - 1] + A[i];
        Prev[i] = i - 1;

        
        if (A[i] > Sum[i]) {
            Sum[i] = A[i];
            Prev[i] = 0;
        } 

        if (Sum[i] > maxSum) {
            maxSum = Sum[i];
            maxEnd = i;
        }
    }

    return maxSum;
}

int main() {
    int i;
    int final;

    while (1)
    {
        maxSum = 0;
        scanf("%d", &n);

        if (n == 0)
        {
            break;
        }
        
        for (i = 1; i <= n; i++) 
        {
            scanf("%d", &A[i]);
        }

        final = maximumSum();

        if (final > 0)
        {
            printf("The maximum winning streak is %d.\n", final);
        }
        else
        {
            printf("Losing streak.\n");
        }
    }

    return 0;
}
