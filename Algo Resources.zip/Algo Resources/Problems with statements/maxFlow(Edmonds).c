/*
 * Problem: Network Bandwidth (Maximum Flow)
 *
 * Given a network of nodes connected by bidirectional links each with a
 * bandwidth (capacity), find the maximum total data per unit time that
 * can be transmitted from source s to destination t simultaneously across
 * all available paths (max-flow).
 *
 * Input:
 *   - Multiple networks until n = 0
 *   - Each network:
 *       * First line: n (number of nodes, 1-indexed)
 *       * Second line: s t c (source, destination, number of connections)
 *       * Next c lines: u v w → bidirectional edge with bandwidth w
 *         (multiple edges between same pair possible)
 *
 * Output:
 *   - "Network X" header
 *   - "The bandwidth is Y."
 *   - Blank line after each test case
 *
 * Approach: Edmonds-Karp (Ford-Fulkerson with BFS for augmenting paths)
 *   - Build a residual capacity matrix cap[u][v]
 *   - For bidirectional edge (u,v,w): cap[u][v] += w and cap[v][u] += w
 *     (both directions independently, since flow in each dir is independent)
 *   - Repeatedly find shortest augmenting path (BFS) from s to t
 *   - Push flow along that path, update residual capacities
 *   - Repeat until no augmenting path exists
 *   - Total flow pushed = maximum bandwidth
 *
 * Complexity: O(V * E^2) — fine for n <= 100
 */

#include <stdio.h>
#include <string.h>

#define MAXN 105
#define INF  0x7fffffff

int cap[MAXN][MAXN];   /* residual capacity matrix */
int parent[MAXN];      /* BFS parent tracking      */
int visited[MAXN];
int queue[MAXN];
int n;

/* BFS: find any augmenting path from s to t in residual graph */
int bfs(int s, int t) {
    memset(visited, 0, sizeof(visited));
    memset(parent, -1, sizeof(parent));

    int front = 0, rear = 0;
    queue[rear++] = s;
    visited[s] = 1;

    while (front < rear) {
        int u = queue[front++];
        if (u == t) return 1;
        for (int v = 1; v <= n; v++) {
            if (!visited[v] && cap[u][v] > 0) {
                visited[v] = 1;
                parent[v] = u;
                queue[rear++] = v;
            }
        }
    }
    return 0; /* no augmenting path found */
}

int maxFlow(int s, int t) {
    int totalFlow = 0;

    while (bfs(s, t)) {
        /* Find bottleneck capacity along the path found by BFS */
        int flow = INF;
        for (int v = t; v != s; v = parent[v]) {
            int u = parent[v];
            if (cap[u][v] < flow) flow = cap[u][v];
        }

        /* Update residual capacities along the path */
        for (int v = t; v != s; v = parent[v]) {
            int u = parent[v];
            cap[u][v] -= flow;
            cap[v][u] += flow;
        }

        totalFlow += flow;
    }

    return totalFlow;
}

int main() {
    int caseNum = 1;

    while (scanf("%d", &n) == 1 && n != 0) {
        int s, t, c;
        scanf("%d %d %d", &s, &t, &c);

        memset(cap, 0, sizeof(cap));

        for (int i = 0; i < c; i++) {
            int u, v, w;
            scanf("%d %d %d", &u, &v, &w);
            /* Bidirectional: add capacity in both directions */
            cap[u][v] += w;
            cap[v][u] += w;
        }

        printf("Network %d\n", caseNum++);
        printf("The bandwidth is %d.\n\n", maxFlow(s, t));
    }

    return 0;
}