/*
 * Problem: Shortest Path (SMTP Latency)
 *
 * Given n servers connected by m bidirectional cables each with a latency,
 * find the shortest time (in ms) to send a message from server S to server T.
 *
 * Input:
 *   - First line: number of test cases N
 *   - Each test case:
 *       * First line: n (servers), m (cables), S (source), T (destination)
 *       * Next m lines: u v w → bidirectional edge between u and v with latency w
 *
 * Output:
 *   - "Case #x: <distance>"  if T is reachable from S
 *   - "Case #x: unreachable" if no path exists
 *
 * Approach: Dijkstra's algorithm with adjacency matrix and linear scan
 *   for minimum distance node. Simple and straightforward for small n.
 */

#include <stdio.h>

#define MAX   20001
#define INF   99999999

int dist[MAX];
int visited[MAX];

int minDistance(int n) {
    int min = INF, minIndex = -1;
    for (int v = 0; v < n; v++) {
        if (!visited[v] && dist[v] < min) {
            min = dist[v];
            minIndex = v;
        }
    }
    return minIndex;
}

/* Adjacency matrix is too large for n=20000, so we use edge list */
typedef struct { int u, v, w; } Edge;
Edge edges[50001];

void dijkstra(int n, int src, int m) {
    for (int i = 0; i < n; i++) {
        dist[i] = INF;
        visited[i] = 0;
    }
    dist[src] = 0;

    for (int count = 0; count < n - 1; count++) {
        int u = minDistance(n);
        if (u == -1) break;
        visited[u] = 1;

        /* Relax all edges incident to u */
        for (int i = 0; i < m; i++) {
            int a = edges[i].u, b = edges[i].v, w = edges[i].w;
            if (a == u && !visited[b] && dist[u] + w < dist[b])
                dist[b] = dist[u] + w;
            if (b == u && !visited[a] && dist[u] + w < dist[a])
                dist[a] = dist[u] + w;
        }
    }
}

int main() {
    int N;
    scanf("%d", &N);

    for (int cas = 1; cas <= N; cas++) {
        int n, m, S, T;
        scanf("%d %d %d %d", &n, &m, &S, &T);

        for (int i = 0; i < m; i++)
            scanf("%d %d %d", &edges[i].u, &edges[i].v, &edges[i].w);

        dijkstra(n, S, m);

        printf("Case #%d: ", cas);
        if (dist[T] == INF)
            printf("unreachable\n");
        else
            printf("%d\n", dist[T]);
    }

    return 0;
}