/*
 * Problem: String Repetition (Largest Exponent)
 *
 * Given a string s, find the largest n such that s = a^n for some string a.
 * i.e., find the maximum number of times a pattern repeats to form s.
 *
 * Input:
 *   - Multiple lines, each containing a string s (length up to 1,000,000)
 *   - Terminated by a line containing just "."
 *
 * Output:
 *   - For each string: the largest n such that s = a^n
 *
 * Approach: KMP Failure Function
 *   The KMP failure function fail[i] gives the length of the longest proper
 *   prefix of s[0..i] that is also a suffix.
 *
 *   Key insight:
 *     Let L = len - fail[len-1]
 *     If len % L == 0, then s is made of (len/L) repetitions of s[0..L-1]
 *     Otherwise, s cannot be expressed as a^n for n > 1, so answer is 1.
 *
 *   Example:
 *     "ababab": len=6, fail[5]=4, L=6-4=2, 6%2==0 → answer = 6/2 = 3
 *     "aaaa":   len=4, fail[3]=3, L=4-3=1, 4%1==0 → answer = 4/1 = 4
 *     "abcd":   len=4, fail[3]=0, L=4-0=4, 4%4==0 → answer = 4/4 = 1
 */

#include <stdio.h>
#include <string.h>

#define MAXLEN 1000002

char s[MAXLEN];
int fail[MAXLEN];

void computeFailure(int len) {
    fail[0] = 0;
    int k = 0;
    for (int i = 1; i < len; i++) {
        while (k > 0 && s[k] != s[i])
            k = fail[k - 1];
        if (s[k] == s[i])
            k++;
        fail[i] = k;
    }
}

int main() {
    while (scanf("%s", s) == 1 && s[0] != '.') {
        int len = strlen(s);
        computeFailure(len);

        int period = len - fail[len - 1]; /* shortest repeating unit length */
        if (len % period == 0)
            printf("%d\n", len / period);
        else
            printf("1\n");
    }

    return 0;
}