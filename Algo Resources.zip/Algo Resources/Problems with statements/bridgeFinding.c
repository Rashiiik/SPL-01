/*
 * Problem: Critical Links (Bridges in a Graph)
 *
 * A "critical link" is a bridge — an edge whose removal disconnects the graph.
 * Given a computer network, find all critical links.
 *
 * Input:
 *   - Multiple datasets until n = 0
 *   - First line: number of servers n
 *   - Next n lines: server_id (degree) neighbor1 neighbor2 ...
 *
 * Output:
 *   - For each dataset: number of critical links, then each bridge "u - v"
 *     listed in ascending order by first endpoint (smaller node first).
 *   - Followed by a blank line after each dataset.
 *
 * Approach: Tarjan's Bridge-Finding Algorithm (DFS-based)
 *   - disc[u]  = discovery time of node u in DFS
 *   - low[u]   = lowest discovery time reachable from subtree rooted at u
 *   - Edge (u,v) is a bridge if low[v] > disc[u]:
 *     meaning v cannot reach u or any ancestor of u without going through (u,v)
 *   - Track parent to avoid treating the reverse of the DFS tree edge as a back edge
 *   - Run DFS from all unvisited nodes to handle disconnected components
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXN 1001
#define MAXE 20001

/* ---------- Adjacency List ---------- */
int head[MAXN], to[MAXE * 2], nxt[MAXE * 2], edgeCnt;

void initGraph(int n) {
    for (int i = 0; i < n; i++) head[i] = -1;
    edgeCnt = 0;
}

void addEdge(int u, int v) {
    to[edgeCnt] = v; nxt[edgeCnt] = head[u]; head[u] = edgeCnt++;
    to[edgeCnt] = u; nxt[edgeCnt] = head[v]; head[v] = edgeCnt++;
}

/* ---------- Tarjan's Bridge Finding ---------- */
int disc[MAXN], low[MAXN], visited[MAXN];
int timer;

/* Bridges stored as pairs (u, v) with u < v */
int bridgeU[MAXE], bridgeV[MAXE], bridgeCnt;

void dfs(int u, int parent) {
    visited[u] = 1;
    disc[u] = low[u] = timer++;

    for (int e = head[u]; e != -1; e = nxt[e]) {
        int v = to[e];
        if (!visited[v]) {
            dfs(v, u);
            if (low[v] < low[u]) low[u] = low[v];
            /* Bridge condition */
            if (low[v] > disc[u]) {
                int a = u < v ? u : v;
                int b = u < v ? v : u;
                bridgeU[bridgeCnt] = a;
                bridgeV[bridgeCnt] = b;
                bridgeCnt++;
            }
        } else if (v != parent) {
            /* Back edge: update low */
            if (disc[v] < low[u]) low[u] = disc[v];
        }
    }
}

/* ---------- Comparison for sorting bridges ---------- */
int cmp(const void *a, const void *b) {
    int *x = (int *)a, *y = (int *)b;
    if (x[0] != y[0]) return x[0] - y[0];
    return x[1] - y[1];
}

int main() {
    int n;
    while (scanf("%d", &n) == 1) {
        initGraph(n);
        memset(visited, 0, sizeof(visited));
        timer = 0;
        bridgeCnt = 0;

        for (int i = 0; i < n; i++) {
            int u, deg;
            char buf[10];
            scanf("%d %s", &u, buf); /* reads the "(deg)" token */
            sscanf(buf + 1, "%d", &deg);
            for (int j = 0; j < deg; j++) {
                int v;
                scanf("%d", &v);
                if (v > u) addEdge(u, v); /* add each undirected edge once */
            }
        }

        /* Run DFS from all unvisited nodes (handles disconnected graph) */
        for (int i = 0; i < n; i++)
            if (!visited[i])
                dfs(i, -1);

        /* Sort bridges by first endpoint */
        int pairs[MAXE][2];
        for (int i = 0; i < bridgeCnt; i++) {
            pairs[i][0] = bridgeU[i];
            pairs[i][1] = bridgeV[i];
        }
        qsort(pairs, bridgeCnt, sizeof(pairs[0]), cmp);

        printf("%d critical links\n", bridgeCnt);
        for (int i = 0; i < bridgeCnt; i++)
            printf("%d - %d\n", pairs[i][0], pairs[i][1]);
        printf("\n");
    }

    return 0;
}