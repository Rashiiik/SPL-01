/*
 * Problem: Freckles - Minimum Spanning Tree (MST)
 *
 * Given n points (freckles) on a 2D plane, find the minimum total length
 * of straight lines needed to connect all points — i.e., the MST of the
 * complete graph where edge weight = Euclidean distance between two points.
 *
 * Input:
 *   - First line: number of test cases T (followed by blank line)
 *   - Each test case (separated by blank lines):
 *       * First line: n (number of freckles)
 *       * Next n lines: x y (coordinates of each freckle)
 *
 * Output:
 *   - For each test case: minimum total ink length to 2 decimal places
 *   - Blank line between consecutive outputs
 *
 * Approach: Prim's Algorithm on a complete graph
 *   - dist[i] = minimum distance from node i to the current MST
 *   - Start with node 0 in MST, dist[0] = 0
 *   - Repeatedly pick the unvisited node with smallest dist[], add to MST
 *   - Update dist[] for all unvisited neighbors
 *   - Sum of all picked distances = MST total length
 *   - O(n^2) — perfectly fine for n <= 100
 */

#include <stdio.h>
#include <math.h>
#include <string.h>

#define MAXN 105
#define INF  1e18

double x[MAXN], y[MAXN];
double dist[MAXN];
int visited[MAXN];

double euclidean(int i, int j) {
    double dx = x[i] - x[j];
    double dy = y[i] - y[j];
    return sqrt(dx * dx + dy * dy);
}

double prim(int n) {
    for (int i = 0; i < n; i++) {
        dist[i] = INF;
        visited[i] = 0;
    }
    dist[0] = 0.0;

    double total = 0.0;

    for (int count = 0; count < n; count++) {
        /* Pick unvisited node with minimum dist */
        int u = -1;
        for (int i = 0; i < n; i++)
            if (!visited[i] && (u == -1 || dist[i] < dist[u]))
                u = i;

        visited[u] = 1;
        total += dist[u];

        /* Update distances to remaining nodes */
        for (int v = 0; v < n; v++) {
            if (!visited[v]) {
                double d = euclidean(u, v);
                if (d < dist[v])
                    dist[v] = d;
            }
        }
    }

    return total;
}

int main() {
    int T;
    scanf("%d", &T);

    for (int t = 0; t < T; t++) {
        if (t > 0) printf("\n");

        int n;
        scanf("%d", &n);
        for (int i = 0; i < n; i++)
            scanf("%lf %lf", &x[i], &y[i]);

        printf("%.2f\n", prim(n));
    }

    return 0;
}