/*
 * Problem: Bicoloring
 *
 * Determine whether a given strongly connected undirected graph can be
 * bicolored — i.e., nodes can be assigned one of two colors such that
 * no two adjacent nodes share the same color.
 *
 * Input:
 *   - Multiple test cases, each starting with n (number of nodes, 1 < n < 200)
 *   - Followed by l (number of edges)
 *   - Followed by l lines each with two node labels (0-indexed) forming an edge
 *   - Input ends when n = 0
 *
 * Output:
 *   - Print "BICOLORABLE." if the graph can be 2-colored, else "NOT BICOLORABLE."
 *
 * Approach: BFS-based bipartite check.
 *   A graph is bicolorable if and only if it contains no odd-length cycle,
 *   which is equivalent to being bipartite. We detect this by BFS-coloring
 *   nodes with alternating colors and checking for same-color conflicts.
 */

#include <stdio.h>
#include <string.h>

#define MAXN 200

int adj[MAXN][MAXN];
int color[MAXN];
int queue[MAXN];

int bfs(int n) {
    int front = 0, rear = 0;
    color[0] = 0;
    queue[rear++] = 0;

    while (front < rear) {
        int u = queue[front++];
        for (int v = 0; v < n; v++) {
            if (!adj[u][v]) continue;
            if (color[v] == -1) {
                color[v] = 1 - color[u];
                queue[rear++] = v;
            } else if (color[v] == color[u]) {
                return 0; // same color neighbor → not bicolorable
            }
        }
    }
    return 1;
}

int main() {
    int n;
    while (scanf("%d", &n) == 1 && n != 0) {
        int l;
        scanf("%d", &l);

        memset(adj, 0, sizeof(adj));
        memset(color, -1, sizeof(color));

        for (int i = 0; i < l; i++) {
            int u, v;
            scanf("%d %d", &u, &v);
            adj[u][v] = 1;
            adj[v][u] = 1;
        }

        if (bfs(n))
            printf("BICOLORABLE.\n");
        else
            printf("NOT BICOLORABLE.\n");
    }

    return 0;
}