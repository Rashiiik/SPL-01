/*
 * Problem: Art Gallery - Critical Point Detection
 *
 * A "critical point" is a point inside a polygon from which the entire
 * interior is NOT visible. Such a point exists if and only if the polygon
 * is NON-CONVEX (concave). A convex polygon has full visibility from every
 * interior point (no critical points).
 *
 * Input:
 *   - Multiple test cases until N = 0
 *   - Each test case: N corner points (x, y) in order (CW or CCW)
 *
 * Output:
 *   - "Yes" if the gallery has a critical point (polygon is non-convex)
 *   - "No"  if the gallery has no critical point (polygon is convex)
 *
 * Approach: Convexity Check via Cross Products
 *   For each consecutive triple of vertices (A, B, C), compute the
 *   cross product of vectors AB and BC:
 *       cross = (B-A) x (C-B)
 *   In a convex polygon, all cross products have the same sign (all
 *   positive for CCW, all negative for CW). If any cross product has
 *   a different sign, the polygon is concave → has a critical point.
 *
 *   Cross product of 2D vectors (ax,ay) and (bx,by):
 *       cross = ax*by - ay*bx
 */

#include <stdio.h>

#define MAXN 55

typedef long long ll;

int main() {
    int n;
    while (scanf("%d", &n) == 1 && n != 0) {
        double x[MAXN], y[MAXN];

        for (int i = 0; i < n; i++)
            scanf("%lf %lf", &x[i], &y[i]);

        int isConvex = 1;
        int sign = 0; /* 0 = not set yet */

        for (int i = 0; i < n; i++) {
            int a = i;
            int b = (i + 1) % n;
            int c = (i + 2) % n;

            /* Vectors AB and BC */
            double ax = x[b] - x[a], ay = y[b] - y[a];
            double bx = x[c] - x[b], by = y[c] - y[b];

            /* Cross product: AB x BC */
            double cross = ax * by - ay * bx;

            if (cross > 0) {
                if (sign == -1) { isConvex = 0; break; }
                sign = 1;
            } else if (cross < 0) {
                if (sign == 1) { isConvex = 0; break; }
                sign = -1;
            }
            /* cross == 0 means collinear — problem says no 3 consecutive
               points are collinear, so this won't happen */
        }

        printf("%s\n", isConvex ? "No" : "Yes");
    }

    return 0;
}