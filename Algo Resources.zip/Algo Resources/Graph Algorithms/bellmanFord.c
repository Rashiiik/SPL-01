
/*
    🫏 BELLMAN–FORD ALGORITHM - DONKEY MODE EXPLANATION

    Imagine:
    - Cities = nodes
    - Roads = directed weighted edges
    - Some roads may even have NEGATIVE cost (weird magic roads)

    🧠 GOAL:
    Find shortest path from ONE source to all cities.

    🐴 DONKEY IDEA:
    1. Start with distance = INF for all cities
    2. Distance[source] = 0
    3. Repeat (V - 1) times:
        → Try improving all edges again and again
    4. If we can still improve → NEGATIVE CYCLE exists 🚨

    🧠 WHY repeat?
    Because shortest paths may need multiple steps to "settle"
*/

/*
==================== SAMPLE INPUT ====================

5
6
0 1 -1
0 2 4
1 2 3
1 3 2
1 4 2
3 2 5
0

======================================================

Meaning:
Start from node 0

======================================================

SAMPLE OUTPUT:

Vertex   Distance from Source
0        0
1        -1
2        2
3        1
4        1

======================================================
*/

#include <stdio.h>

#define MAX 100
#define INF 99999

/*
    🫏 EDGE = one directed road
*/
struct Edge {
    int u, v, w;
};

/*
    🫏 BELLMAN-FORD MAIN LOGIC
*/
void bellmanFord(struct Edge edges[], int n, int e, int src) {

    int dist[MAX];

    // Step 1: initialize all distances
    for (int i = 0; i < n; i++) {
        dist[i] = INF;
    }

    dist[src] = 0;

    /*
        🫏 Step 2:
        Repeat V-1 times:
        try relaxing all edges
    */
    for (int i = 1; i <= n - 1; i++) {

        for (int j = 0; j < e; j++) {

            int u = edges[j].u;
            int v = edges[j].v;
            int w = edges[j].w;

            // if we found a better path
            if (dist[u] != INF && dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
            }
        }
    }

    /*
        🫏 Step 3:
        If still improving → negative cycle exists
    */
    for (int j = 0; j < e; j++) {

        int u = edges[j].u;
        int v = edges[j].v;
        int w = edges[j].w;

        if (dist[u] != INF && dist[u] + w < dist[v]) {
            printf("\nNegative weight cycle detected!\n");
            return;
        }
    }

    printf("\nVertex \t Distance from Source\n");

    for (int i = 0; i < n; i++) {
        printf("%d \t %d\n", i, dist[i]);
    }
}

int main() {

    int n, e, src;
    struct Edge edges[MAX];

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    printf("Enter edges (u v w):\n");

    for (int i = 0; i < e; i++) {
        scanf("%d %d %d",
              &edges[i].u,
              &edges[i].v,
              &edges[i].w);
    }

    printf("Enter source vertex: ");
    scanf("%d", &src);

    bellmanFord(edges, n, e, src);

    return 0;
}