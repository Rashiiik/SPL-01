
/*
    🫏 FLOYD–WARSHALL ALGORITHM - DONKEY MODE EXPLANATION

    Imagine:
    - Cities = nodes
    - Roads = direct distances between cities

    🧠 GOAL:
    Find the SHORTEST PATH between EVERY pair of cities.

    🐴 DONKEY IDEA:
    Instead of thinking directly:
        "Is there a better path from i to j?"

    We ask:
        "Is going through city k better?"

    So we try EVERY city k as an intermediate stop.
*/

/*
==================== SAMPLE INPUT ====================

4
5
0 1 5
0 3 10
1 2 3
2 3 1
0 2 100

======================================================

Graph:
0 → 1 (5)
0 → 3 (10)
1 → 2 (3)
2 → 3 (1)
0 → 2 (100)

======================================================

SAMPLE OUTPUT (final idea):

Shortest distances matrix:
0  5  8  9
INF 0  3  4
INF INF 0  1
INF INF INF 0

======================================================
*/

#include <stdio.h>

#define MAX 100
#define INF 99999

/*
    🫏 prints matrix after each k step
*/
void printMatrix(int dist[MAX][MAX], int n, int k) {

    printf("\nAfter using vertex %d:\n", k);

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {

            if (dist[i][j] == INF)
                printf("%4s", "INF");
            else
                printf("%4d", dist[i][j]);
        }
        printf("\n");
    }
}

/*
    🫏 MAIN IDEA:
    try every node k as a middle point
*/
void floydWarshall(int graph[MAX][MAX], int n) {

    int dist[MAX][MAX];

    // copy graph into dist matrix
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            dist[i][j] = graph[i][j];

    // 🫏 try every possible middle city k
    for (int k = 0; k < n; k++) {

        for (int i = 0; i < n; i++) {

            for (int j = 0; j < n; j++) {

                if (dist[i][k] != INF &&
                    dist[k][j] != INF &&
                    dist[i][k] + dist[k][j] < dist[i][j]) {

                    dist[i][j] = dist[i][k] + dist[k][j];
                }
            }
        }

        printMatrix(dist, n, k);
    }

    // 🫏 negative cycle check
    for (int i = 0; i < n; i++) {
        if (dist[i][i] < 0) {
            printf("\nNegative cycle detected!\n");
            return;
        }
    }

    printf("\nFinal shortest distance matrix printed above.\n");
}

int main() {

    int n, e;
    int graph[MAX][MAX];

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    // initialize graph
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {

            if (i == j)
                graph[i][j] = 0;
            else
                graph[i][j] = INF;
        }
    }

    printf("Enter edges (u v w):\n");

    for (int i = 0; i < e; i++) {
        int u, v, w;
        scanf("%d %d %d", &u, &v, &w);

        graph[u][v] = w;

        // uncomment for undirected graph
        // graph[v][u] = w;
    }

    floydWarshall(graph, n);

    return 0;
}