
/*
    🫏 DIJKSTRA’S ALGORITHM - DONKEY MODE EXPLANATION

    Imagine:
    - Cities = nodes
    - Roads = weighted paths (costs)

    🧠 GOAL:
    Find shortest distance from ONE source city to ALL others.

    🐴 DONKEY IDEA:
    1. Start from source city
    2. Always pick the closest unvisited city
    3. Update its neighbors if we find a cheaper route
    4. Repeat until all cities are processed

    🚨 IMPORTANT:
    - Works only for NON-negative weights
*/

/*
==================== SAMPLE INPUT ====================

5
7
0 1 10
0 2 3
1 2 1
1 3 2
2 1 4
2 3 8
3 4 7
0

======================================================

Meaning:
Start from node 0

======================================================

SAMPLE OUTPUT:

Vertex   Distance from Source
0        0
1        7
2        3
3        9
4        16

======================================================
*/

#include <stdio.h>

#define MAX 100
#define INF 99999

/*
    🫏 pick the nearest unvisited node
*/
int minDistance(int dist[], int visited[], int n) {
    int min = INF, minIndex = -1;

    for (int v = 0; v < n; v++) {
        if (!visited[v] && dist[v] < min) {
            min = dist[v];
            minIndex = v;
        }
    }

    return minIndex;
}

/*
    🫏 MAIN DIJKSTRA LOGIC
*/
void dijkstra(int graph[MAX][MAX], int n, int src) {

    int dist[MAX];
    int visited[MAX];

    // initialize
    for (int i = 0; i < n; i++) {
        dist[i] = INF;
        visited[i] = 0;
    }

    dist[src] = 0;

    // repeat n-1 times
    for (int count = 0; count < n - 1; count++) {

        int u = minDistance(dist, visited, n);

        // safety check
        if (u == -1) break;

        visited[u] = 1;

        // update neighbors
        for (int v = 0; v < n; v++) {

            if (!visited[v] &&
                graph[u][v] != 0 &&
                dist[u] + graph[u][v] < dist[v]) {

                dist[v] = dist[u] + graph[u][v];
            }
        }
    }

    printf("\nVertex \t Distance from Source\n");

    for (int i = 0; i < n; i++) {
        printf("%d \t %d\n", i, dist[i]);
    }
}

int main() {

    int V, E, graph[MAX][MAX], src;

    // 🫏 clear graph
    for (int i = 0; i < MAX; i++)
        for (int j = 0; j < MAX; j++)
            graph[i][j] = 0;

    printf("Enter number of vertices: ");
    scanf("%d", &V);

    printf("Enter number of edges: ");
    scanf("%d", &E);

    printf("Enter edges (u v w):\n");

    for (int i = 0; i < E; i++) {
        int u, v, w;
        scanf("%d %d %d", &u, &v, &w);

        graph[u][v] = w;
        graph[v][u] = w; // undirected graph
    }

    printf("Enter source: ");
    scanf("%d", &src);

    dijkstra(graph, V, src);

    return 0;
}