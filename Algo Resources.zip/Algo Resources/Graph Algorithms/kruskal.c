
/*
    🫏 KRUSKAL’S ALGORITHM (MINIMUM SPANNING TREE) - DONKEY MODE EXPLANATION

    Imagine:
    - Cities = nodes
    - Roads = edges with cost (weight)
    - Goal = connect ALL cities with MINIMUM total cost

    🧠 DONKEY IDEA:
    1. Sort all roads by cheapest first
    2. Pick roads one by one
    3. BUT only if they DO NOT form a cycle
    4. Stop when all cities are connected

    🚨 Cycle check is done using UNION-FIND (Disjoint Set)
*/

/*
==================== SAMPLE INPUT ====================

4
5
0 1 10
0 2 6
0 3 5
1 3 15
2 3 4

======================================================

Meaning:
Nodes: 0,1,2,3
Edges with weights

======================================================

SAMPLE OUTPUT:

Edges in MST:
2 - 3   4
0 - 3   5
0 - 1   10

Total Cost of MST: 19

======================================================
*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 100

/*
    🫏 EDGE = road between two cities with cost
*/
struct Edge {
    int u, v, w;
};

int parent[MAX];

/*
    🫏 FIND = find which group a node belongs to
    (keeps going up until root parent is found)
*/
int find(int i) {
    while (parent[i] != i)
        i = parent[i];
    return i;
}

/*
    🫏 UNION = connect two groups
*/
void unionSets(int a, int b) {
    int rootA = find(a);
    int rootB = find(b);
    parent[rootA] = rootB;
}

/*
    🫏 SORT EDGES BY WEIGHT (cheapest first)
*/
void sortEdges(struct Edge edges[], int e) {
    for (int i = 0; i < e - 1; i++) {
        for (int j = 0; j < e - i - 1; j++) {

            if (edges[j].w > edges[j + 1].w) {

                struct Edge temp = edges[j];
                edges[j] = edges[j + 1];
                edges[j + 1] = temp;
            }
        }
    }
}

/*
    🫏 KRUSKAL MAIN LOGIC
*/
void kruskal(struct Edge edges[], int n, int e) {

    struct Edge mst[MAX];
    int mstIndex = 0;
    int totalCost = 0;

    // each node is its own group initially
    for (int i = 0; i < n; i++)
        parent[i] = i;

    // sort roads by cost
    sortEdges(edges, e);

    for (int i = 0; i < e; i++) {

        int u = edges[i].u;
        int v = edges[i].v;

        // 🫏 if they are in different groups → safe to connect
        if (find(u) != find(v)) {

            mst[mstIndex++] = edges[i];
            totalCost += edges[i].w;

            unionSets(u, v);
        }
    }

    printf("\nEdges in MST:\n");

    for (int i = 0; i < mstIndex; i++) {
        printf("%d - %d \t%d\n",
               mst[i].u,
               mst[i].v,
               mst[i].w);
    }

    printf("\nTotal Cost of MST: %d\n", totalCost);
}

int main() {

    int n, e;
    struct Edge edges[MAX];

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    printf("Enter edges (u v w):\n");

    for (int i = 0; i < e; i++) {
        scanf("%d %d %d",
              &edges[i].u,
              &edges[i].v,
              &edges[i].w);
    }

    kruskal(edges, n, e);

    return 0;
}