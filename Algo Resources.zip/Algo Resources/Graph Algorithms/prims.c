
/*
    🫏 PRIM’S ALGORITHM (MINIMUM SPANNING TREE) - DONKEY MODE EXPLANATION

    Imagine:
    - Cities = nodes
    - Roads = weighted edges (cost)
    - Goal = connect ALL cities with MINIMUM total cost

    🧠 DONKEY IDEA:
    1. Start from any city (we start from 0)
    2. Always pick the CHEAPEST road that connects:
       - visited city → unvisited city
    3. Repeat until all cities are connected

    🚨 Difference from Kruskal:
    - Kruskal: pick cheapest edge globally
    - Prim: grow one tree step by step
*/

/*
==================== SAMPLE INPUT ====================

5
7
0 1 2
0 3 6
1 2 3
1 3 8
1 4 5
2 4 7
3 4 9

======================================================

Graph:
      0
     / \
    1   3
   / \   \
  2   4 ---

======================================================

SAMPLE OUTPUT:

Edges in MST:
0 - 1   2
1 - 2   3
1 - 4   5
0 - 3   6

Total Cost: 16

======================================================
*/

#include <stdio.h>

#define MAX 100
#define INF 99999

int graph[MAX][MAX];
int key[MAX];
int parent[MAX];
int mstSet[MAX];

/*
    🫏 pick the closest unvisited node
*/
int minKey(int n) {
    int min = INF, minIndex = -1;

    for (int v = 0; v < n; v++) {
        if (!mstSet[v] && key[v] < min) {
            min = key[v];
            minIndex = v;
        }
    }

    return minIndex;
}

/*
    🫏 PRIM MAIN LOGIC
*/
void prim(int n) {

    // initialize everything
    for (int i = 0; i < n; i++) {
        key[i] = INF;
        mstSet[i] = 0;
    }

    // start from node 0
    key[0] = 0;
    parent[0] = -1;

    for (int count = 0; count < n - 1; count++) {

        // pick cheapest node not yet in MST
        int u = minKey(n);

        mstSet[u] = 1;

        // update neighbors
        for (int v = 0; v < n; v++) {

            if (graph[u][v] &&
                !mstSet[v] &&
                graph[u][v] < key[v]) {

                parent[v] = u;
                key[v] = graph[u][v];
            }
        }
    }

    int totalCost = 0;

    printf("\nEdges in MST:\n");

    for (int i = 1; i < n; i++) {
        printf("%d - %d \t%d\n",
               parent[i],
               i,
               graph[i][parent[i]]);

        totalCost += graph[i][parent[i]];
    }

    printf("\nTotal Cost: %d\n", totalCost);
}

int main() {

    int n, e;

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    // clear graph
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            graph[i][j] = 0;

    printf("Enter edges (u v w):\n");

    for (int i = 0; i < e; i++) {
        int u, v, w;
        scanf("%d %d %d", &u, &v, &w);

        graph[u][v] = w;
        graph[v][u] = w; // undirected graph
    }

    prim(n);

    return 0;
}