#include <stdio.h>
#include <stdlib.h>

#define MAX 100

typedef struct {
    int x, y;
} Point;

Point p0;

// Swap points
void swap(Point *a, Point *b) {
    Point temp = *a;
    *a = *b;
    *b = temp;
}

// Orientation: 0 collinear, 1 clockwise, 2 counterclockwise
int orientation(Point a, Point b, Point c) {
    int val = (b.y - a.y) * (c.x - b.x) -
              (b.x - a.x) * (c.y - b.y);

    if (val == 0) return 0;
    return (val > 0) ? 1 : 2;
}

// Distance squared
int dist(Point a, Point b) {
    return (a.x - b.x)*(a.x - b.x) +
           (a.y - b.y)*(a.y - b.y);
}

// Comparator for sorting by polar angle
int compare(const void *a, const void *b) {
    Point *p1 = (Point *)a;
    Point *p2 = (Point *)b;

    int o = orientation(p0, *p1, *p2);

    if (o == 0)
        return (dist(p0, *p2) >= dist(p0, *p1)) ? -1 : 1;

    return (o == 2) ? -1 : 1;
}

// Print convex hull
void grahamScan(Point points[], int n) {

    // Step 1: Find bottom-most point
    int ymin = points[0].y;
    int min = 0;

    for (int i = 1; i < n; i++) {
        if (points[i].y < ymin ||
           (points[i].y == ymin && points[i].x < points[min].x)) {
            ymin = points[i].y;
            min = i;
        }
    }

    swap(&points[0], &points[min]);
    p0 = points[0];

    // Step 2: Sort by polar angle
    qsort(&points[1], n - 1, sizeof(Point), compare);

    // Step 3: Build hull using stack
    Point stack[MAX];
    int top = -1;

    stack[++top] = points[0];
    stack[++top] = points[1];
    stack[++top] = points[2];

    for (int i = 3; i < n; i++) {

        while (top > 0 &&
               orientation(stack[top - 1], stack[top], points[i]) != 2) {
            top--;
        }

        stack[++top] = points[i];
    }

    // Output result
    printf("\nConvex Hull Points:\n");
    for (int i = 0; i <= top; i++) {
        printf("(%d, %d)\n", stack[i].x, stack[i].y);
    }
}

int main() {
    int n;
    Point points[MAX];

    printf("Enter number of points: ");
    scanf("%d", &n);

    printf("Enter points (x y):\n");
    for (int i = 0; i < n; i++) {
        scanf("%d %d", &points[i].x, &points[i].y);
    }

    grahamScan(points, n);

    return 0;
}