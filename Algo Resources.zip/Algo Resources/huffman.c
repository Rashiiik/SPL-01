
/*
    🫏 HUFFMAN CODING - DONKEY MODE EXPLANATION

    Imagine:
    - Characters = letters
    - Frequency = how often they appear

    🧠 GOAL:
    Give SHORT codes to frequent characters
    and LONG codes to rare characters
    → to compress data efficiently

    🐴 DONKEY IDEA:
    1. Put all characters into a MIN HEAP (lowest frequency first)
    2. Repeatedly combine 2 smallest nodes
    3. Build a binary tree
    4. Assign:
        left = 0
        right = 1
    5. Root-to-leaf path = Huffman code

    🚨 GREEDY IDEA:
    Always merge the two smallest frequencies first
*/

/*
==================== SAMPLE INPUT ====================

6
a b c d e f
5 9 12 13 16 45

======================================================

SAMPLE OUTPUT:

f: 0
c: 100
d: 101
a: 1100
b: 1101
e: 111

======================================================
*/

#include <stdio.h>
#include <stdlib.h>

#define MAX 100

/*
    🫏 NODE = character + frequency
*/
typedef struct Node {
    char data;
    int freq;
    struct Node *left, *right;
} Node;

/*
    🫏 MIN HEAP structure
*/
typedef struct {
    int size;
    Node* arr[MAX];
} MinHeap;

/*
    🫏 create new node
*/
Node* createNode(char data, int freq) {

    Node* node = (Node*)malloc(sizeof(Node));

    node->data = data;
    node->freq = freq;
    node->left = node->right = NULL;

    return node;
}

/*
    🫏 swap nodes
*/
void swap(Node** a, Node** b) {

    Node* temp = *a;
    *a = *b;
    *b = temp;
}

/*
    🫏 heapify (keep min heap property)
*/
void heapify(MinHeap* heap, int i) {

    int smallest = i;
    int left = 2*i + 1;
    int right = 2*i + 2;

    if (left < heap->size &&
        heap->arr[left]->freq < heap->arr[smallest]->freq)
        smallest = left;

    if (right < heap->size &&
        heap->arr[right]->freq < heap->arr[smallest]->freq)
        smallest = right;

    if (smallest != i) {
        swap(&heap->arr[i], &heap->arr[smallest]);
        heapify(heap, smallest);
    }
}

/*
    🫏 extract minimum frequency node
*/
Node* extractMin(MinHeap* heap) {

    Node* temp = heap->arr[0];

    heap->arr[0] = heap->arr[heap->size - 1];
    heap->size--;

    heapify(heap, 0);

    return temp;
}

/*
    🫏 insert into heap
*/
void insertHeap(MinHeap* heap, Node* node) {

    int i = heap->size++;
    heap->arr[i] = node;

    while (i && heap->arr[(i - 1)/2]->freq > heap->arr[i]->freq) {

        swap(&heap->arr[i], &heap->arr[(i - 1)/2]);
        i = (i - 1)/2;
    }
}

/*
    🫏 build Huffman tree
*/
Node* buildHuffman(char data[], int freq[], int n) {

    MinHeap heap;
    heap.size = 0;

    // insert all characters into heap
    for (int i = 0; i < n; i++)
        insertHeap(&heap, createNode(data[i], freq[i]));

    // combine until one node remains
    while (heap.size > 1) {

        Node* left = extractMin(&heap);
        Node* right = extractMin(&heap);

        Node* merged = createNode('$',
                                  left->freq + right->freq);

        merged->left = left;
        merged->right = right;

        insertHeap(&heap, merged);
    }

    return extractMin(&heap);
}

/*
    🫏 print codes (DFS traversal)
*/
void printCodes(Node* root, int arr[], int top) {

    if (root->left) {
        arr[top] = 0;
        printCodes(root->left, arr, top + 1);
    }

    if (root->right) {
        arr[top] = 1;
        printCodes(root->right, arr, top + 1);
    }

    // leaf node = actual character
    if (!root->left && !root->right) {

        printf("%c: ", root->data);

        for (int i = 0; i < top; i++)
            printf("%d", arr[i]);

        printf("\n");
    }
}

int main() {

    int n;
    char data[MAX];
    int freq[MAX];

    printf("Enter number of characters: ");
    scanf("%d", &n);

    printf("Enter characters:\n");

    for (int i = 0; i < n; i++)
        scanf(" %c", &data[i]);

    printf("Enter frequencies:\n");

    for (int i = 0; i < n; i++)
        scanf("%d", &freq[i]);

    Node* root = buildHuffman(data, freq, n);

    int arr[MAX], top = 0;

    printf("\nHuffman Codes:\n");

    printCodes(root, arr, top);

    return 0;
}