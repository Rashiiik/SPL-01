
/*
    🫏 DFS (DEPTH FIRST SEARCH) - DONKEY MODE EXPLANATION

    Imagine:
    - Each node = a town
    - Roads connect towns
    - DFS = "go deep first, don’t care about neighbors yet"

    HOW IT WORKS:
    1. Start from a node
    2. Visit it
    3. Go to one unvisited neighbor immediately
    4. Keep going deeper until stuck
    5. Then go back (backtrack)

    🧠 SIMPLE IDEA:
    DFS = like exploring a maze by always going forward until no way left
*/

/*
==================== SAMPLE INPUT ====================

5
5
0 1
0 2
1 3
1 4
2 4
0

======================================================

Graph:
      0
     / \
    1   2
   / \   \
  3   4 ---

Start DFS from node 0

======================================================

SAMPLE OUTPUT (one possible):

DFS traversal: 0 1 3 4 2
======================================================
*/

#include <stdio.h>

#define MAX 100

int adj[MAX][MAX];
int visited[MAX];

/*
    🫏 DFS = go deep before exploring other options
*/
void dfs(int node, int V) {
    visited[node] = 1;

    printf("%d ", node);

    for (int i = 0; i < V; i++) {

        // if road exists and not visited
        if (adj[node][i] == 1 && !visited[i]) {

            // go deeper immediately
            dfs(i, V);
        }
    }
}

int main() {
    int V, E;

    printf("Enter number of vertices: ");
    scanf("%d", &V);

    printf("Enter number of edges: ");
    scanf("%d", &E);

    // initialize graph + visited array
    for (int i = 0; i < V; i++) {
        visited[i] = 0;

        for (int j = 0; j < V; j++) {
            adj[i][j] = 0;
        }
    }

    printf("Enter edges (u v):\n");
    for (int i = 0; i < E; i++) {
        int u, v;
        scanf("%d %d", &u, &v);

        adj[u][v] = 1;
        adj[v][u] = 1; // remove for directed graph
    }

    int start;
    printf("Enter starting vertex: ");
    scanf("%d", &start);

    printf("DFS traversal: ");
    dfs(start, V);

    return 0;
}