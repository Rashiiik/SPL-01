
/*
    🫏 TOPOLOGICAL SORT (KAHN’S ALGORITHM) - DONKEY MODE EXPLANATION

    Imagine:
    - Each node = a task
    - Directed edge u → v means:
        "u must be done BEFORE v"

    🧠 GOAL:
    Find an order of tasks such that:
    - No task appears before its prerequisites

    HOW WE THINK (DONKEY VERSION):
    1. Count how many prerequisites each task has (indegree)
    2. Start with tasks that have NO prerequisites (indegree = 0)
    3. Do them first
    4. Remove their effect (reduce indegree of others)
    5. Repeat

    🚨 If we cannot process all nodes → there is a cycle
*/

/*
==================== SAMPLE INPUT ====================

6
6
5 2
5 0
4 0
4 1
2 3
3 1

======================================================

Meaning:
5 → 2, 0
4 → 0, 1
2 → 3
3 → 1

======================================================

SAMPLE OUTPUT:

Topological Order: 4 5 0 2 3 1
(or any valid ordering)

======================================================
*/

#include <stdio.h>

#define MAX 100

int adj[MAX][MAX];
int indegree[MAX];
int queue[MAX];

int main() {
    int V, E;

    printf("Enter number of vertices: ");
    scanf("%d", &V);

    printf("Enter number of edges: ");
    scanf("%d", &E);

    // 🫏 reset everything
    for (int i = 0; i < V; i++) {
        indegree[i] = 0;

        for (int j = 0; j < V; j++) {
            adj[i][j] = 0;
        }
    }

    printf("Enter directed edges (u v):\n");
    for (int i = 0; i < E; i++) {
        int u, v;
        scanf("%d %d", &u, &v);

        adj[u][v] = 1;

        // v has one more prerequisite
        indegree[v]++;
    }

    int front = 0, rear = 0;

    // 🫏 start with tasks that need nothing
    for (int i = 0; i < V; i++) {
        if (indegree[i] == 0) {
            queue[rear++] = i;
        }
    }

    int count = 0;

    printf("Topological Order: ");

    while (front < rear) {

        int u = queue[front++];
        printf("%d ", u);
        count++;

        // remove u from graph effect
        for (int v = 0; v < V; v++) {

            if (adj[u][v] == 1) {

                indegree[v]--;

                // if v is now free, add to queue
                if (indegree[v] == 0) {
                    queue[rear++] = v;
                }
            }
        }
    }

    // 🫏 cycle check
    if (count != V) {
        printf("\nGraph has a cycle! No topological order possible.\n");
    }

    return 0;
}