
/*
    🫏 CONNECTED COMPONENTS (DFS) - DONKEY MODE EXPLANATION

    Imagine:
    - Each node = a town
    - Roads connect some towns
    - If you can travel between towns → same group (component)

    🧠 IDEA:
    We use DFS to "flood" through all connected towns.

    RULE:
    - If a town is NOT visited → it starts a NEW component
    - DFS from it marks all reachable towns as part of same group
*/

/*
==================== SAMPLE INPUT ====================

6
4
0 1
1 2
3 4
4 5

======================================================

Graph:
Component 1: 0 - 1 - 2
Component 2: 3 - 4 - 5

======================================================

SAMPLE OUTPUT:

Connected Components:
Component 1: 0 1 2
Component 2: 3 4 5

Total components = 2
======================================================
*/

#include <stdio.h>

#define MAX 100

int adj[MAX][MAX];
int visited[MAX];

/*
    🫏 DFS = explore everything connected to a node
*/
void dfs(int node, int V) {
    visited[node] = 1;

    printf("%d ", node);

    for (int i = 0; i < V; i++) {

        // if road exists and not visited → go there
        if (adj[node][i] == 1 && !visited[i]) {
            dfs(i, V);
        }
    }
}

int main() {
    int V, E;

    printf("Enter number of vertices: ");
    scanf("%d", &V);

    printf("Enter number of edges: ");
    scanf("%d", &E);

    // clear graph + visited
    for (int i = 0; i < V; i++) {
        visited[i] = 0;

        for (int j = 0; j < V; j++) {
            adj[i][j] = 0;
        }
    }

    printf("Enter edges (u v):\n");
    for (int i = 0; i < E; i++) {
        int u, v;
        scanf("%d %d", &u, &v);

        adj[u][v] = 1;
        adj[v][u] = 1; // undirected graph
    }

    int count = 0;

    printf("\nConnected Components:\n");

    for (int i = 0; i < V; i++) {

        // if not visited → new component found
        if (!visited[i]) {
            count++;

            printf("Component %d: ", count);

            dfs(i, V);

            printf("\n");
        }
    }

    printf("\nTotal components = %d\n", count);

    return 0;
}