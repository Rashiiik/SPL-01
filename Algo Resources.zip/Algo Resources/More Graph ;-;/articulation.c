
/*
    🫏 ARTICULATION POINTS (DONKEY MODE EXPLANATION)

    Imagine:
    - Each vertex = a town
    - Each edge = road between towns
    - We check which town is SO IMPORTANT that if removed,
      the whole network breaks into pieces.

    We use DFS (deep walking through graph) and track:

    d[u]   = time when we first visit town u
    low[u] = earliest visited town reachable from u (including back roads)

    🧠 MAIN IDEA:
    If a child cannot reach above its parent in DFS tree,
    then parent is an ARTICULATION POINT.

    RULES:
    1. Root node:
       - If it has 2 or more DFS children → it's important

    2. Non-root node:
       - If low[child] >= d[parent] → parent is important
*/

/*
==================== SAMPLE INPUT ====================

5
5
0 1
1 2
2 0
1 3
3 4

======================================================

Explanation:
Graph:
    0
   / \
  1---2
  |
  3
  |
  4

Expected articulation points:
1, 3
======================================================

SAMPLE OUTPUT:

Articulation Points (important towns):
1 3
======================================================
*/

#include <stdio.h>

#define MAX 100
#define WHITE 0
#define GRAY 1
#define BLACK 2

int adj[MAX][MAX];
int color[MAX];
int prev[MAX];
int d[MAX];
int low[MAX];
int ap[MAX];
int V;
int time = 0;

/*
    DFS visit = explore a town fully
*/
void DFS_Visit(int u, int isRoot) {
    color[u] = GRAY;

    d[u] = low[u] = ++time;

    int children = 0;

    for (int v = 0; v < V; v++) {

        if (adj[u][v] == 0) continue;

        if (color[v] == WHITE) {
            prev[v] = u;
            children++;

            DFS_Visit(v, 0);

            if (low[v] < low[u])
                low[u] = low[v];

            // 🫏 if child cannot go above me → I'm important
            if (!isRoot && low[v] >= d[u]) {
                ap[u] = 1;
            }
        }

        else if (v != prev[u]) {
            if (d[v] < low[u])
                low[u] = d[v];
        }
    }

    color[u] = BLACK;

    // 🫏 root rule
    if (isRoot && children > 1) {
        ap[u] = 1;
    }
}

/*
    DFS wrapper
*/
void DFS() {
    for (int u = 0; u < V; u++) {
        color[u] = WHITE;
        prev[u] = -1;
        low[u] = 1000000;
        d[u] = 1000000;
        ap[u] = 0;
    }

    time = 0;

    for (int u = 0; u < V; u++) {
        if (color[u] == WHITE) {
            DFS_Visit(u, 1);
        }
    }
}

int main() {
    int E;

    printf("Enter vertices: ");
    scanf("%d", &V);

    printf("Enter edges: ");
    scanf("%d", &E);

    for (int i = 0; i < V; i++)
        for (int j = 0; j < V; j++)
            adj[i][j] = 0;

    printf("Enter edges (u v):\n");
    for (int i = 0; i < E; i++) {
        int u, v;
        scanf("%d %d", &u, &v);

        adj[u][v] = 1;
        adj[v][u] = 1;
    }

    DFS();

    printf("\nArticulation Points (important towns):\n");

    for (int i = 0; i < V; i++) {
        if (ap[i])
            printf("%d ", i);
    }

    return 0;
}