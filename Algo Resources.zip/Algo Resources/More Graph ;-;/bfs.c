/*
    🫏 BFS (BREADTH FIRST SEARCH) - DONKEY MODE EXPLANATION

    Imagine:
    - Each node = a town
    - Roads connect towns
    - BFS = "visit nearest towns first before going far"

    HOW IT WORKS:
    1. Start from a node
    2. Put it in a queue
    3. Visit it
    4. Add all its unvisited neighbors to queue
    5. Repeat

    🧠 SIMPLE IDEA:
    BFS explores level by level (like ripples in water)
*/

/*
==================== SAMPLE INPUT ====================

5
5
0 1
0 2
1 3
1 4
2 4
0

======================================================

Explanation:
Graph:
      0
     / \
    1   2
   / \   \
  3   4 ---

Start BFS from node 0

======================================================

SAMPLE OUTPUT:

BFS traversal: 0 1 2 3 4
======================================================
*/

#include <stdio.h>

#define MAX 100

int adj[MAX][MAX];
int visited[MAX];
int queue[MAX];

/*
    BFS = level-by-level visiting
*/
void bfs(int start, int V) {
    int front = 0, rear = 0;

    // 🫏 put first town in queue
    queue[rear++] = start;
    visited[start] = 1;

    while (front < rear) {

        // take first town from queue
        int current = queue[front++];

        printf("%d ", current);

        // check all possible neighbors
        for (int i = 0; i < V; i++) {

            // if road exists and not visited
            if (adj[current][i] == 1 && !visited[i]) {

                // add to queue (future visits)
                queue[rear++] = i;
                visited[i] = 1;
            }
        }
    }
}

int main() {
    int V, E;

    printf("Enter number of vertices: ");
    scanf("%d", &V);

    printf("Enter number of edges: ");
    scanf("%d", &E);

    // clear graph + visited array
    for (int i = 0; i < V; i++) {
        visited[i] = 0;

        for (int j = 0; j < V; j++) {
            adj[i][j] = 0;
        }
    }

    printf("Enter edges (u v):\n");
    for (int i = 0; i < E; i++) {
        int u, v;
        scanf("%d %d", &u, &v);

        adj[u][v] = 1;
        adj[v][u] = 1; // undirected graph
    }

    int start;
    printf("Enter starting vertex: ");
    scanf("%d", &start);

    printf("BFS traversal: ");
    bfs(start, V);

    return 0;
}