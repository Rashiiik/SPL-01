#include <stdio.h>

// Function to compute LIS using Naive DP
void LIS_Naive_DP(int a[], int n, int L[], int prev[],
                  int *maxLength, int *maxIndex)
{
    // Initialization
    L[0] = 0;
    prev[0] = -1;

    *maxLength = 0;
    *maxIndex = 0;

    for (int i = 1; i < n; i++) {
        L[i] = 0;
        prev[i] = -1;

        for (int j = 0; j < i; j++) {
            if (a[j] < a[i] && L[j] + 1 > L[i]) {
                L[i] = L[j] + 1;
                prev[i] = j;
            }
        }

        if (L[i] > *maxLength) {
            *maxLength = L[i];
            *maxIndex = i;
        }
    }
}

// Print LIS using prev[] array
void printLIS(int a[], int prev[], int index)
{
    if (index == -1)
        return;

    printLIS(a, prev, prev[index]);
    printf("%d ", a[index]);
}

int main()
{
    int a[] = {10, 22, 9, 33, 21, 50, 41, 60};
    int n = sizeof(a) / sizeof(a[0]);

    int L[n];
    int prev[n];
    int maxLength, maxIndex;

    LIS_Naive_DP(a, n, L, prev, &maxLength, &maxIndex);

    printf("L array: ");
    for (int i = 0; i < n; i++)
        printf("%d ", L[i]);

    printf("\nprev array: ");
    for (int i = 0; i < n; i++)
        printf("%d ", prev[i]);

    printf("\n\nLength of LIS = %d\n", maxLength + 1);
    printf("LIS = ");
    printLIS(a, prev, maxIndex);
    printf("\n");

    return 0;
}
