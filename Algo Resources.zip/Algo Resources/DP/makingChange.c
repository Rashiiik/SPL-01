#include <stdio.h>
#include <limits.h>

#define MAX 1000

void makeChange(int coins[], int n, int C) {
    int dp[MAX];      // dp[i] = min coins needed to make amount i
    int used[MAX];    // used[i] = coin used to reach amount i

    // Initialize dp array
    dp[0] = 0;
    for (int i = 1; i <= C; i++) {
        dp[i] = INT_MAX;
        used[i] = -1;
    }

    // Fill dp table
    for (int i = 1; i <= C; i++) {
        for (int j = 0; j < n; j++) {
            if (coins[j] <= i && dp[i - coins[j]] != INT_MAX) {
                if (dp[i - coins[j]] + 1 < dp[i]) {
                    dp[i] = dp[i - coins[j]] + 1;
                    used[i] = coins[j]; // track which coin was used
                }
            }
        }
    }

    // Result
    if (dp[C] == INT_MAX) {
        printf("Cannot make exact change for %d\n", C);
        return;
    }

    printf("Minimum coins needed for %d: %d\n", C, dp[C]);

    // Trace back which coins were used
    printf("Coins used: ");
    int amount = C;
    while (amount > 0) {
        printf("%d ", used[amount]);
        amount -= used[amount];
    }
    printf("\n");
}

int main() {
    // Coin denominations: v1 < v2 < ... < vn
    int coins[] = {1, 5, 10, 25};
    int n = sizeof(coins) / sizeof(coins[0]);
    int C = 67;

    makeChange(coins, n, C);
    return 0;
}