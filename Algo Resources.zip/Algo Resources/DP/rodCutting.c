#include <stdio.h>

#define MAX 100

int memo[MAX];
int p[MAX];
int cut[MAX];

int max(int x, int y) {
    return (x > y) ? x : y;
}

int rodCut(int n) {

    if (memo[n] != -1)
    {
        return memo[n];
    }

    if (n == 0) 
    {
        memo[n] = 0;
        cut[n] = 0;  
    } 
    else 
    {
        memo[n] = 0;
        cut[n] = 0;
        for (int i = 0; i < n; i++) 
        {
            int priceWithCut = p[i] + rodCut(n - (i + 1));

            if (priceWithCut > memo[n]) 
            {
                memo[n] = priceWithCut;
                cut[n] = i + 1;  
            }
        }
    }

    return memo[n];
}

void printCuts(int n) {

    printf("Cuts: ");

    while (n > 0) 
    {
        printf("%d ", cut[n]);
        n -= cut[n];
    }
}

int main() {

    int n;
    scanf("%d", &n);

    for (int i = 0; i < n; i++)
    {
        scanf("%d", &p[i]);
    }

    for (int i = 0; i <= n; i++) 
    {
        memo[i] = -1;
        cut[i] = 0;
    }

    int price = rodCut(n);

    printf("Max Price: %d\n", price);
    printCuts(n);

    return 0;
}
