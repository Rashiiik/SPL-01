#include <stdio.h>

#define MAXN 1000

int A[MAXN + 1];     // input array (1-based indexing)
int Sum[MAXN + 1];   // DP array
int Prev[MAXN + 1];  // predecessor array
int n;

/* Recursive function to print the max-sum interval */
void Print_MaxSumInterval(int i) {
    if (Prev[i] > 0) {
        Print_MaxSumInterval(Prev[i]);
    }
    printf("%d ", A[i]);
}

int main() {
    int i;
    int maxSum, maxEnd;

    /* Input */
    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter elements:\n");
    for (i = 1; i <= n; i++) {
        scanf("%d", &A[i]);
    }

    /* Initialization */
    Sum[0] = 0;
    maxSum = A[1];
    maxEnd = 1;

    printf("\nStep-by-step DP decisions:\n");

    /* Kadane + path tracking */
    for (i = 1; i <= n; i++) {

        /* Try extending previous interval */
        Sum[i] = Sum[i - 1] + A[i];
        Prev[i] = i - 1;

        /* Or start new interval */
        if (A[i] > Sum[i]) {
            Sum[i] = A[i];
            Prev[i] = 0;
            printf("i=%d: Start new interval with %d (Sum=%d)\n",
                   i, A[i], Sum[i]);
        } else {
            printf("i=%d: Add %d → New Sum=%d\n",
                   i, A[i], Sum[i]);
        }

        /* Track maximum */
        if (Sum[i] > maxSum) {
            maxSum = Sum[i];
            maxEnd = i;
        }
    }

    /* Output */
    printf("\nMaximum Sum = %d\n", maxSum);
    printf("Max Sum Interval: ");
    Print_MaxSumInterval(maxEnd);
    printf("\n");

    return 0;
}
