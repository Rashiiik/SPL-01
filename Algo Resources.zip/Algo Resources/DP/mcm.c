#include <stdio.h>
#include <limits.h>

#define MAX 100
#define INF INT_MAX

int m[MAX][MAX];   // cost table
int s[MAX][MAX];   // split table

// Memoized recursive MCM
int LOOKUP_CHAIN(int p[], int i, int j)
{
    if (m[i][j] < INF)
        return m[i][j];

    if (i == j) {
        m[i][j] = 0;
    } else {
        for (int k = i; k <= j - 1; k++) {
            int q = LOOKUP_CHAIN(p, i, k)
                  + LOOKUP_CHAIN(p, k + 1, j)
                  + p[i - 1] * p[k] * p[j];

            if (q < m[i][j]) {
                m[i][j] = q;
                s[i][j] = k;   // store split
            }
        }
    }
    return m[i][j];
}

// Print optimal parenthesization
void PRINT_OPTIMAL_PARENS(int i, int j)
{
    if (i == j) {
        printf("A%d", i);
    } else {
        printf("(");
        PRINT_OPTIMAL_PARENS(i, s[i][j]);
        printf(" x ");
        PRINT_OPTIMAL_PARENS(s[i][j] + 1, j);
        printf(")");
    }
}

int main()
{
    int p[] = {30, 35, 15, 5, 10, 20, 25};
    int n = sizeof(p) / sizeof(p[0]) - 1; // number of matrices

    // Initialize tables
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            m[i][j] = INF;
            s[i][j] = 0;
        }
    }

    int minCost = LOOKUP_CHAIN(p, 1, n);

    printf("Minimum number of multiplications = %d\n", minCost);
    printf("Optimal multiplication order: ");
    PRINT_OPTIMAL_PARENS(1, n);
    printf("\n");

    return 0;
}
