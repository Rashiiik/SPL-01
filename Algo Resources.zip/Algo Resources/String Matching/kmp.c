
/*
    🫏 KMP STRING MATCHING - DONKEY MODE EXPLANATION

    Imagine:
    - Text = long book
    - Pattern = word you are searching

    🧠 NORMAL WAY (bad):
    - If mismatch → start again from next position ❌ (slow)

    🧠 KMP IDEA (smart donkey):
    - If mismatch happens, DON'T restart fully
    - Use previous knowledge of pattern (LPS array)

    🐴 LPS = "Longest Prefix which is also Suffix"
*/

/*
==================== SAMPLE INPUT ====================

text = ababcabcabababd
pattern = ababd

======================================================

SAMPLE OUTPUT:

Pattern found at index 10

======================================================
*/

#include <stdio.h>
#include <string.h>

#define MAX 1000

/*
    🫏 build LPS array (pattern self-knowledge)
*/
void buildLPS(char pattern[], int m, int lps[]) {

    int len = 0;
    lps[0] = 0;

    int i = 1;

    while (i < m) {

        if (pattern[i] == pattern[len]) {
            len++;
            lps[i] = len;
            i++;
        }
        else {

            if (len != 0) {
                len = lps[len - 1];
            }
            else {
                lps[i] = 0;
                i++;
            }
        }
    }
}

/*
    🫏 KMP SEARCH ENGINE
*/
void KMP(char text[], char pattern[]) {

    int n = strlen(text);
    int m = strlen(pattern);

    int lps[MAX];

    buildLPS(pattern, m, lps);

    int i = 0; // text pointer
    int j = 0; // pattern pointer

    while (i < n) {

        // match → move both
        if (text[i] == pattern[j]) {
            i++;
            j++;
        }

        // full match found
        if (j == m) {
            printf("Pattern found at index %d\n", i - j);
            j = lps[j - 1];
        }

        // mismatch
        else if (i < n && text[i] != pattern[j]) {

            if (j != 0)
                j = lps[j - 1];   // use memory (DONKEY SMART STEP)
            else
                i++;
        }
    }
}

int main() {

    char text[MAX], pattern[MAX];

    printf("Enter text: ");
    scanf("%s", text);

    printf("Enter pattern: ");
    scanf("%s", pattern);

    KMP(text, pattern);

    return 0;
}