#include <stdio.h>
#include <string.h>

#define MAX 1000

void naiveSearch(char text[], char pattern[]) {
    int n = strlen(text);
    int m = strlen(pattern);
    int found = 0;

    printf("\nMatching positions: ");

    for (int i = 0; i <= n - m; i++) {
        int j;

        // check pattern match at position i
        for (j = 0; j < m; j++) {
            if (text[i + j] != pattern[j])
                break;
        }

        if (j == m) {
            printf("%d ", i);
            found = 1;
        }
    }

    if (!found)
        printf("No match found");

    printf("\n");
}

int main() {
    char text[MAX], pattern[MAX];

    printf("Enter text: ");
    scanf("%s", text);

    printf("Enter pattern: ");
    scanf("%s", pattern);

    naiveSearch(text, pattern);

    return 0;
}