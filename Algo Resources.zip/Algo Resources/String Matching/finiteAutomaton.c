
/*
    🫏 FINITE AUTOMATA STRING MATCHING - DONKEY MODE EXPLANATION

    Imagine:
    - Text = long string (book)
    - Pattern = word we want to find

    🧠 IDEA:
    Instead of checking characters repeatedly,
    we build a MACHINE (DFA = Deterministic Finite Automaton)

    🐴 DONKEY WAY TO THINK:
    - Each state = how much of pattern we have matched so far
    - Input character → machine jumps to next state
    - If we reach final state → pattern found

    🚨 KEY IDEA:
    We PRECOMPUTE all transitions (like a cheat sheet)
*/

/*
==================== SAMPLE INPUT ====================

text = ababcabcabababd
pattern = ababd

======================================================

SAMPLE OUTPUT:

Pattern found at index 10

======================================================
*/

#include <stdio.h>
#include <string.h>

#define MAX 256   // ASCII size

/*
    🫏 compute next state for DFA
*/
int getNextState(char pattern[], int m, int state, int x) {

    if (state < m && x == pattern[state])
        return state + 1;

    int ns, i;

    for (ns = state; ns > 0; ns--) {

        if (pattern[ns - 1] == x) {

            for (i = 0; i < ns - 1; i++) {

                if (pattern[i] != pattern[state - ns + 1 + i])
                    break;
            }

            if (i == ns - 1)
                return ns;
        }
    }

    return 0;
}

/*
    🫏 build DFA transition table
*/
void buildDFA(char pattern[], int m, int TF[][MAX]) {

    int state, x;

    for (state = 0; state <= m; state++) {

        for (x = 0; x < MAX; x++) {

            TF[state][x] = getNextState(pattern, m, state, x);
        }
    }
}

/*
    🫏 search using DFA machine
*/
void search(char text[], char pattern[]) {

    int n = strlen(text);
    int m = strlen(pattern);

    int TF[m + 1][MAX];

    buildDFA(pattern, m, TF);

    int state = 0;

    for (int i = 0; i < n; i++) {

        state = TF[state][(unsigned char)text[i]];

        if (state == m) {
            printf("Pattern found at index %d\n", i - m + 1);
        }
    }
}

int main() {

    char text[1000], pattern[100];

    printf("Enter text: ");
    scanf("%s", text);

    printf("Enter pattern: ");
    scanf("%s", pattern);

    search(text, pattern);

    return 0;
}