#include <stdio.h>
#include <string.h>

#define d 256      // number of characters (ASCII)
#define q 101      // a prime number for modulo

void rabinKarp(char text[], char pattern[]) {
    int n = strlen(text);
    int m = strlen(pattern);

    int i, j;
    int p = 0; // hash value for pattern
    int t = 0; // hash value for text window
    int h = 1;

    // The value of h = d^(m-1) % q
    for (i = 0; i < m - 1; i++)
        h = (h * d) % q;

    // Calculate initial hash values
    for (i = 0; i < m; i++) {
        p = (d * p + pattern[i]) % q;
        t = (d * t + text[i]) % q;
    }

    // Slide pattern over text
    for (i = 0; i <= n - m; i++) {

        // If hash matches, check characters
        if (p == t) {
            for (j = 0; j < m; j++) {
                if (text[i + j] != pattern[j])
                    break;
            }

            if (j == m)
                printf("Pattern found at index %d\n", i);
        }

        // Compute hash for next window
        if (i < n - m) {
            t = (d * (t - text[i] * h) + text[i + m]) % q;

            // handle negative hash
            if (t < 0)
                t = t + q;
        }
    }
}

int main() {
    char text[1000], pattern[100];

    printf("Enter text: ");
    scanf("%s", text);

    printf("Enter pattern: ");
    scanf("%s", pattern);

    rabinKarp(text, pattern);

    return 0;
}