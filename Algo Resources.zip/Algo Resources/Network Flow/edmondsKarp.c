
/*
    🫏 EDMONDS–KARP ALGORITHM (MAX FLOW) - DONKEY MODE EXPLANATION

    Imagine:
    - Cities = nodes
    - Pipes = edges with capacity
    - We want MAX water from SOURCE → SINK

    🧠 WHAT MAKES IT SPECIAL?
    Instead of any random path (like DFS),
    we ALWAYS pick the SHORTEST path (fewest edges) using BFS.

    🐴 DONKEY IDEA:
    1. Build residual graph (remaining capacities)
    2. Use BFS to find shortest path from source to sink
    3. Send maximum possible flow through that path (bottleneck)
    4. Update residual graph
    5. Repeat until no path exists

    🚨 WHY BFS?
    - Guarantees optimal number of steps
    - Prevents worst-case behavior of DFS Ford-Fulkerson
*/

/*
==================== SAMPLE INPUT ====================

6
9
0 1 16
0 2 13
1 2 10
1 3 12
2 1 4
2 4 14
3 2 9
3 5 20
4 3 7
0 5

======================================================

Graph:
Source = 0
Sink = 5

======================================================

SAMPLE OUTPUT (example):

Step 1:
0 -> 1 -> 3 -> 5
Bottleneck = 12

Step 2:
0 -> 2 -> 4 -> 3 -> 5
Bottleneck = 7

Maximum Flow = 19

======================================================
*/

#include <stdio.h>
#include <string.h>

#define MAX 100
#define INF 99999

int graph[MAX][MAX];
int residual[MAX][MAX];
int parent[MAX];
int visited[MAX];
int n;

/*
    🫏 BFS = find shortest augmenting path
*/
int bfs(int source, int sink) {

    int queue[MAX], front = 0, rear = 0;

    memset(visited, 0, sizeof(visited));
    memset(parent, -1, sizeof(parent));

    queue[rear++] = source;
    visited[source] = 1;

    while (front < rear) {

        int u = queue[front++];

        for (int v = 0; v < n; v++) {

            if (!visited[v] && residual[u][v] > 0) {

                queue[rear++] = v;
                parent[v] = u;
                visited[v] = 1;

                if (v == sink)
                    return 1;
            }
        }
    }

    return 0;
}

/*
    🫏 print augmenting path
*/
void printPath(int source, int sink) {

    int path[MAX];
    int count = 0;

    for (int v = sink; v != -1; v = parent[v]) {
        path[count++] = v;
    }

    printf("Augmenting Path: ");

    for (int i = count - 1; i >= 0; i--) {
        printf("%d", path[i]);
        if (i != 0) printf(" -> ");
    }

    printf("\n");
}

/*
    🫏 EDMONDS-KARP MAIN LOGIC
*/
int edmondsKarp(int source, int sink) {

    int maxFlow = 0;
    int step = 1;

    // initialize residual graph
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            residual[i][j] = graph[i][j];

    printf("\nInitial Residual Graph:\n");

    while (bfs(source, sink)) {

        printf("\nStep %d\n", step++);

        printPath(source, sink);

        // find bottleneck
        int pathFlow = INF;

        for (int v = sink; v != source; v = parent[v]) {

            int u = parent[v];

            if (residual[u][v] < pathFlow)
                pathFlow = residual[u][v];
        }

        printf("Bottleneck Flow = %d\n", pathFlow);

        // update residual graph
        for (int v = sink; v != source; v = parent[v]) {

            int u = parent[v];

            residual[u][v] -= pathFlow;
            residual[v][u] += pathFlow;
        }

        maxFlow += pathFlow;

        // print residual graph
        printf("Residual Graph:\n");

        for (int i = 0; i < n; i++) {

            for (int j = 0; j < n; j++) {
                printf("%3d ", residual[i][j]);
            }

            printf("\n");
        }
    }

    return maxFlow;
}

int main() {

    int e, source, sink;

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    memset(graph, 0, sizeof(graph));

    printf("Enter edges (u v capacity):\n");

    for (int i = 0; i < e; i++) {

        int u, v, w;
        scanf("%d %d %d", &u, &v, &w);

        graph[u][v] = w;
    }

    printf("Enter source and sink: ");
    scanf("%d %d", &source, &sink);

    int maxFlow = edmondsKarp(source, sink);

    printf("\n====================\n");
    printf("Maximum Flow = %d\n", maxFlow);
    printf("====================\n");

    return 0;
}