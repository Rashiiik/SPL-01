
/*
    🫏 FORD–FULKERSON (MAX FLOW) - DONKEY MODE EXPLANATION

    Imagine:
    - Nodes = cities
    - Edges = pipes
    - Capacity = how much water can flow through pipe

    🧠 GOAL:
    Find MAXIMUM water we can send from SOURCE → SINK

    🐴 DONKEY IDEA:
    1. Start with original graph (capacities)
    2. Try to find a path from source to sink
    3. Send as much flow as possible through that path
       (called bottleneck)
    4. Reduce capacity along path, add reverse capacity
    5. Repeat until no path exists

    🚨 KEY IDEA:
    We constantly update a "residual graph"
*/

/*
==================== SAMPLE INPUT ====================

4
5
0 1 100
0 2 100
1 2 1
1 3 100
2 3 100
0 3

======================================================

Graph:
Source = 0
Sink = 3

======================================================

SAMPLE OUTPUT (example):

Step 1:
Path: 0 -> 1 -> 3
Bottleneck = 100

Step 2:
Path: 0 -> 2 -> 3
Bottleneck = 100

Maximum Flow = 200

======================================================
*/

#include <stdio.h>
#include <string.h>

#define MAX 100
#define INF 99999

int graph[MAX][MAX];
int residual[MAX][MAX];
int visited[MAX];
int parent[MAX];
int n;

/*
    🫏 print path from source to sink
*/
void printPath(int source, int sink) {

    int path[MAX];
    int count = 0;

    for (int v = sink; v != -1; v = parent[v]) {
        path[count++] = v;
    }

    printf("Augmenting Path: ");

    for (int i = count - 1; i >= 0; i--) {
        printf("%d", path[i]);
        if (i != 0) printf(" -> ");
    }

    printf("\n");
}

/*
    🫏 DFS to find any path with remaining capacity
*/
int dfs(int u, int sink) {

    if (u == sink)
        return 1;

    visited[u] = 1;

    for (int v = 0; v < n; v++) {

        if (!visited[v] && residual[u][v] > 0) {

            parent[v] = u;

            if (dfs(v, sink))
                return 1;
        }
    }

    return 0;
}

/*
    🫏 print residual graph (remaining capacities)
*/
void printResidual() {

    printf("\nResidual Graph:\n");

    for (int i = 0; i < n; i++) {

        for (int j = 0; j < n; j++) {
            printf("%3d ", residual[i][j]);
        }

        printf("\n");
    }
}

/*
    🫏 MAIN MAX FLOW LOGIC
*/
int fordFulkerson(int source, int sink) {

    int maxFlow = 0;
    int step = 1;

    // initialize residual graph
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            residual[i][j] = graph[i][j];

    printf("\nInitial Residual Graph:");
    printResidual();

    // keep finding paths
    while (1) {

        memset(visited, 0, sizeof(visited));
        memset(parent, -1, sizeof(parent));

        // if no path exists → stop
        if (!dfs(source, sink))
            break;

        printf("\nStep %d\n", step++);

        printPath(source, sink);

        // 🫏 find bottleneck (minimum capacity in path)
        int pathFlow = INF;

        for (int v = sink; v != source; v = parent[v]) {

            int u = parent[v];

            if (residual[u][v] < pathFlow)
                pathFlow = residual[u][v];
        }

        printf("Bottleneck Flow = %d\n", pathFlow);

        // update residual graph
        for (int v = sink; v != source; v = parent[v]) {

            int u = parent[v];

            residual[u][v] -= pathFlow;
            residual[v][u] += pathFlow;
        }

        printResidual();

        maxFlow += pathFlow;
    }

    return maxFlow;
}

int main() {

    int e;

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter number of edges: ");
    scanf("%d", &e);

    memset(graph, 0, sizeof(graph));

    printf("Enter edges (u v capacity):\n");

    for (int i = 0; i < e; i++) {

        int u, v, w;
        scanf("%d %d %d", &u, &v, &w);

        graph[u][v] = w;
    }

    int source, sink;

    printf("Enter source and sink: ");
    scanf("%d %d", &source, &sink);

    int maxFlow = fordFulkerson(source, sink);

    printf("\n====================\n");
    printf("Maximum Flow = %d\n", maxFlow);
    printf("====================\n");

    return 0;
}