#include <stdio.h>

#define MAX 100

/*
    🫏 ACTIVITY SELECTION PROBLEM - GREEDY APPROACH

    PROBLEM:
    You are given activities with start and finish times.
    Select the maximum number of activities such that
    no two activities overlap.

    🧠 GREEDY IDEA (DONKEY VERSION):
    - Always pick the activity that finishes EARLIEST
    - Because it leaves maximum room for others
*/

struct Activity {
    int start;
    int finish;
};

/*
    🫏 sort activities by finish time (simple bubble sort)
*/
void sortByFinish(struct Activity a[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (a[j].finish > a[j + 1].finish) {
                struct Activity temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }
}

/*
    🫏 greedy selection function
*/
void activitySelection(struct Activity a[], int n) {

    sortByFinish(a, n);

    printf("\nSelected Activities:\n");

    // first activity is always selected
    int count = 1;
    int lastFinish = a[0].finish;

    printf("(%d, %d)\n", a[0].start, a[0].finish);

    for (int i = 1; i < n; i++) {

        // if activity starts after last selected finishes
        if (a[i].start >= lastFinish) {

            printf("(%d, %d)\n", a[i].start, a[i].finish);

            lastFinish = a[i].finish;
            count++;
        }
    }

    printf("\nTotal selected activities = %d\n", count);
}

int main() {

    int n;
    struct Activity a[MAX];

    printf("Enter number of activities: ");
    scanf("%d", &n);

    printf("Enter start and finish times:\n");

    for (int i = 0; i < n; i++) {
        scanf("%d %d", &a[i].start, &a[i].finish);
    }

    activitySelection(a, n);

    return 0;
}